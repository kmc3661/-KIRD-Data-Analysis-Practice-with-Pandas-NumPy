def mod1_add(a, b):
    return a+b